<?php

declare(strict_types=1);

namespace ClickHouseDB\Exception;

interface ClickHouseException
{
}
