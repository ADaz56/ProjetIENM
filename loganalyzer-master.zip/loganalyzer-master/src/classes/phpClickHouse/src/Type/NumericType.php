<?php

declare(strict_types=1);

namespace ClickHouseDB\Type;

interface NumericType extends Type
{
}
